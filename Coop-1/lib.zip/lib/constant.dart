import 'dart:ui';

const defaultPadding = 16.0;

const kLightBlue = Color.fromARGB(255, 69, 219, 147);
const kDarkBlue = Color.fromARGB(255, 50, 220, 192);
const kGreen = Color(0xff8AC53E);
const kOrange = Color(0xffFF993A);
const kYellow = Color(0xffFFD143);
