import 'package:flutter/material.dart';

class Transfere extends StatelessWidget {
  final List<String> cooperativeList;

  Transfere({required this.cooperativeList});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nouvelle Transaction'),
      ),
      body: ListView.builder(
        itemCount: cooperativeList.length,
        itemBuilder: (context, index) {
          final cooperativeName = cooperativeList[index];
          return ListTile(
            title: Text(cooperativeName),
            onTap: () {
              // Action lorsque l'utilisateur sélectionne une coopérative
              // Vous pouvez naviguer vers un écran de détails de la transaction ou effectuer d'autres actions.
              // Par exemple, vous pouvez utiliser la fonction Navigator pour naviguer vers une autre page :
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TransactionDetailsScreen(
                    cooperativeName: cooperativeName,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class TransactionDetailsScreen extends StatelessWidget {
  final String cooperativeName;

  TransactionDetailsScreen({required this.cooperativeName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Détails de la transaction'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Coopérative : $cooperativeName',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            // Autres widgets pour les détails de la transaction
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: Transfere(
      cooperativeList: ['Coopérative A', 'Coopérative B', 'Coopérative C'],
    ),
  ));
}
